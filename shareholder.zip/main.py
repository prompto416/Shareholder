import time
import datetime
import gspread
from oauth2client.service_account import ServiceAccountCredentials

scope =['https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]
creds = ServiceAccountCredentials.from_json_keyfile_name('testSheetAPI_Key.json', scope)
client = gspread.authorize(creds)
targetSheet = "AAV"
folderID = "1hSJLJfkPfgKdOW7sQAovRq3fUntZzkEa"
summary = client.open(targetSheet,folderID).worksheet('Summary')
investorSheet = client.open(targetSheet,folderID).worksheet('Investor')
fundSheet = client.open(targetSheet,folderID).worksheet('Fund')


def num2col(n):
    """Number to Excel-style column name, e.g., 1 = A, 26 = Z, 27 = AA, 703 = AAA."""
    name = ''
    while n > 0:
        n, r = divmod (n - 1, 26)
        name = chr(r + ord('A')) + name
    return name

def col2num(name):
    """Excel-style column name to number, e.g., A = 1, Z = 26, AA = 27, AAA = 703."""
    n = 0
    for c in name:
        n = n * 26 + 1 + ord(c) - ord('A')
    return n



def getFundOrInvestor(userInput):
    #0 = Fund
    #1 = Investory
    #3 = Full List
    summaryColumnB = summary.get('B2:B9999')

    fundAndInvestor =  []
    titleMatcher = ['บริษัท','ห้างหุ่นส่วน','กองทุน','จำกัด','มหาชน','limited','company','listed','publicly','partnership','fund'
            ,'incorporation','corporation','ltd.','inc.']
    for i in summaryColumnB:
        for j in i:
            fundAndInvestor.append(j)
    fundAndInvestor = list(dict.fromkeys(fundAndInvestor))
    if userInput == 3:
        return fundAndInvestor
    fundAndInvestor = [ele.lower() for ele in fundAndInvestor]

    investor = fundAndInvestor
    fund = [ele for ele in fundAndInvestor if any(funds in ele for funds in titleMatcher)]
    for ele in fund:
        if ele in investor:
            investor.remove(ele)

    if userInput == 0:
        return list(dict.fromkeys(fund))
    elif userInput == 1:
        return list(dict.fromkeys(investor))
    else:
        print("ValueError: INVALID INPUT!!!")
        raise ValueError
        return ValueError

# fund = getFundOrInvestor(0)
# investor = getFundOrInvestor(1)
# fundAndInvestor = fund+investor
summaryB2 = summary.get('B2:B9999')
summaryB2 = [item for sublist in summaryB2 for item in sublist]

#post-requisite data for appendPerformanceToList function
def getInterestedPerformance(interestedData,month):
    profitList = []
    lossList = []
    lossCount = 0
    profitCount = 0


    if month == 1:
        monthIndex = 3
    elif month == 3:
        monthIndex = 4
    elif month == 6:
        monthIndex = 5
    elif month == 12:
        monthIndex = 6
    else:
        print('Invalid Month input')
        quit()
    for i in range(len(interestedData)):
        if float(interestedData[i][1]) < 0:
            buyOrSell = 'sell'
        elif float(interestedData[i][1]) >= 0:
            buyOrSell = 'buy'
        priceAction = float(interestedData[i][2])
        priceMonth = interestedData[i][monthIndex]
        if priceMonth == '-':

            return ['-']
        priceMonth = float(priceMonth)
        if (buyOrSell == 'buy'):
            if priceAction < priceMonth:
                lossCount += 1
                lossList.append(priceMonth - priceAction)
            elif priceAction > priceMonth:
                profitCount += 1
                profitList.append(priceAction - priceMonth)
        elif buyOrSell == 'sell':
            if priceAction > priceMonth:
                profitCount += 1
                profitList.append(priceAction - priceMonth)
            elif priceAction < priceMonth:
                lossCount += 1
                lossList.append(priceMonth - priceAction)
        else:
            print('invalid buy or sell input')
            quit()

    interestedCount = len(interestedData)

    performanceMonth = ((profitCount / interestedCount))
    print(profitCount)
    print(interestedCount)
    print(performanceMonth,'%%%%%%%%%%')


    try:
        maxProfit = max(profitList)
    except:
        maxProfit = 0
    try:
        avgProfit = sum(profitList)/profitCount
    except ZeroDivisionError:
        avgProfit = '-'
    try:
        maxLoss = max(lossList)
    except:
        maxLoss = 0
    try:
        avgLoss = sum(lossList)/lossCount
    except:
        avgLoss = '-'
    interestedStats =  [performanceMonth,maxProfit,avgProfit,maxLoss,avgLoss]
    # for i in range(len(interestedStats)):
    #     if type(interestedStats[i]) == float:
    #         interestedStats[i] = float((f"{interestedStats[i]:.{2}f}"))
    for i in range(len(interestedStats)):
        try:
            interestedStats[i] = f"{float(interestedStats[i]):.2f}"
        except:
            pass

    return interestedStats


def appendPerformanceToList(interested):
    originInterested = interested
    interested = interested.lower()
    interestedPerformance = [interested]
    oldMax = -9999999999999
    listOfOccurence = []
    colBtoI = summary.get('B2:I999')
    #buy or sell will be determined by negative and positive number instead
    # buyOrSell = summary.get('Z2:Z999')
    for i in range(len(colBtoI)):
        if colBtoI[i][0].lower() == interested:
            listOfOccurence.append(colBtoI[i])
    interested1month = getInterestedPerformance(listOfOccurence,1)
    interested3month = getInterestedPerformance(listOfOccurence,3)
    interested6month = getInterestedPerformance(listOfOccurence,6)
    interested12month = getInterestedPerformance(listOfOccurence,12)
    interestColumn = interested1month+interested3month+interested6month+interested12month
    interestColumn.insert(0,originInterested)
    interestColumn.insert(1,len(listOfOccurence))
    return interestColumn
def labelColumn():
    # fundSheet.update("B1","hello world")
    labelColAB = ["Name","#Trade"]
    labelColC = ["Performance","Max Profit","Avg Profit ( Sum Profit / # Profit )","Max Loss","Avg Loss ( Sum Loss / # Loss)"]
    fundSheet.update("A1",labelColAB[0])
    fundSheet.update("B1",labelColAB[1])
    labelCellList = fundSheet.range("C1:G1")
    for i,val in enumerate(labelColC):
        labelCellList[i].value = val
    fundSheet.update_cells(labelCellList)


# fundCellList = fundSheet.range('B2:I3')
# for i in range(len(fundCellList)):
#     fundCellList[i].value =
# fundSheet.update_cells(fundCellList)


res = []
fund = getFundOrInvestor(0)
count = 2

for i in fund:
    if count % 10 == 0 :
        print('sleeping for a minute')
        time.sleep(60)
    dataToWrite = appendPerformanceToList(i)
    fundCellList = fundSheet.range(f"A{count}:V{count}")
    for j in range(len(fundCellList)):
        try:
            fundCellList[j].value = dataToWrite[j]
        except IndexError:
            pass
    fundSheet.update_cells(fundCellList)
    count+=1
time.sleep(60)
investor = getFundOrInvestor(1)
for i in investor:
    if count % 10 == 0 :
        print('sleeping for a minute')
        time.sleep(60)
    dataToWrite = appendPerformanceToList(i)
    investorCellList = investorSheet.range(f"A{count}:V{count}")
    for j in range(len(investorCellList)):
        try:
            investorCellList[j].value = dataToWrite[j]
        except IndexError:
            pass
    investorSheet.update_cells(investorCellList)
    count+=1







